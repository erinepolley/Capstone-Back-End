from django.apps import AppConfig


class BackendappConfig(AppConfig):
    name = 'backendapp'
