#!c:\users\erin polley\workspace\capstone-backend2\plantpal\capstoneenv\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
